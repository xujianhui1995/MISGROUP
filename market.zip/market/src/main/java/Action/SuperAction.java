package Action;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionSupport;

import Dao.SaledaoImpl;
import Dao.SuperdaoImpl;
import Service.Saleservice;
import Service.Superservice;
import Entity.Store;
import Entity.User;
import Entity.Sale;
import Dbutil.DbUtil;

public class SuperAction extends ActionSupport {
	//��װ����
	private String userID;
	private String roleID;
	private String password;
	private String name;
	private String tel;
	private String address;
	
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getRoleID() {
		return roleID;
	}
	public void setRoleID(String roleID) {
		this.roleID = roleID;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
/***************************************************/
	public String NewUser() throws Exception{
		SuperdaoImpl superdaoImpl=new SuperdaoImpl();
		Superservice superservice=new Superservice();
		superservice.setSuperdao(superdaoImpl);
		User user=new User();
		user.setUserID(getUserID());
		user.setRoleID(getRoleID());
		user.setName(getName());
		user.setPassword(getPassword());
		user.setTel(getTel());
		user.setAddress(getAddress());
		superservice.UpdateUser(user);
		return SUCCESS;		
	}
	public String DelUser() throws Exception{
		SuperdaoImpl superdaoImpl=new SuperdaoImpl();
		Superservice superservice=new Superservice();
		superservice.setSuperdao(superdaoImpl);
		User user=new User();
		user.setUserID(getUserID());		
		superservice.UpdateUser(user);
		return SUCCESS;		
	}
		

}

