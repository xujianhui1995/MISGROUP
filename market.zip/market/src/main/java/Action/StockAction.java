package Action;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;

import Entity.Goods;
import Entity.Stock;
import Service.StockService;

public class StockAction extends ActionSupport {
	public String goodsName;
	public String sort;
	public String unit;
	public int safety;
	public Date date;
	public float price;
	public int addNumber;
   public String goodsID;
	public int getAddNumber() {
		return addNumber;
	}

	public void setAddNumber(int addNumber) {
		this.addNumber = addNumber;
	}

	private List<Stock> sList = new ArrayList<Stock>();
	private List<Stock> aList = new ArrayList<Stock>();
	private Map<String, Object> maps = new HashMap<String, Object>();

	public Map<String, Object> getMaps() {
		return maps;
	}

	public void setMaps(Map<String, Object> maps) {
		this.maps = maps;
	}

	public List<Stock> getsList() {
		return sList;
	}

	public void setsList(List<Stock> sList) {
		this.sList = sList;
	}

	public String input() {
		StockService ss = new StockService();
		Goods g = new Goods();
		g.setGoodsName(goodsName);
		g.setSortID(sort);
		g.setUnit(unit);
		g.setSafety(safety);
		g.setDate(date);
		g.setPrice(price);
		boolean b1 = ss.addGood(g);
		return SUCCESS;
	}

	public String show() {
		StockService ss = new StockService();
		// System.out.println("aaaaaaaaaaaaaa");
		sList = ss.getAll();
		maps.put("rows", sList);
		maps.put("page", sList.size());
		/*
		 * for(Stock stock:sList){ stock.getGoodsID();ad stock.getGoodsName();
		 * stock.getRest(); }
		 */

		/*
		 * HttpServletRequest request = ServletActionContext.getRequest();
		 * request.setAttribute("List1", sList);
		 */
		return SUCCESS;
	}

	public String showAlarm() {
		StockService ss = new StockService();
		aList = ss.getAlarmStock();
		maps.put("rows", aList);
		maps.put("page", aList.size());
		// HttpServletRequest request = ServletActionContext.getRequest();
		// request.setAttribute("List1", ss);
		return SUCCESS;
	}
	public String addStock(){
		StockService ss = new StockService();
		Stock s=ss.getBygoodsID(goodsID);
	    boolean b1=ss.addNumber(s, addNumber);
		return SUCCESS;
	}
}
