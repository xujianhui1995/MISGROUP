package Action;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionSupport;

import Dao.PurchaseImpl;
import Service.Purchaseservice;
import Entity.Order;
import Entity.Supply;
import Dbutil.DbUtil;

public class PurchaseAction extends ActionSupport {
	//��װ����
	private String orderID;
	private String date;
	private String goodsName;
	private String number;
	private String price;
	private String supply;
	private String state;
	private String actor;
	private String supplyID;
	private String supplyname;
	private String tel;
	private String address;
	public String getSupplyID() {
		return supplyID;
	}
	public void setSupplyID(String supplyID) {
		this.supplyID = supplyID;
	}
	public String getSupplyname() {
		return supplyname;
	}
	public void setSupplyname(String supplyname) {
		this.supplyname = supplyname;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getOrderID() {
		return orderID;
	}
	public void setOrderID(String orderID) {
		this.orderID = orderID;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getGoodsName() {
		return goodsName;
	}
	public void setGoodsName(String goodsName) {
		this.goodsName = goodsName;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getSupply() {
		return supply;
	}
	public void setSupply(String supply) {
		this.supply = supply;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getActor() {
		return actor;
	}
	public void setActor(String actor) {
		this.actor = actor;
	}
/***************************************************/
	public String BuildOrder() throws Exception{
		try{
			PurchaseImpl purchaseImpl=new PurchaseImpl();
			Purchaseservice purchaseservice=new Purchaseservice();
			purchaseservice.setPurchasedao(purchaseImpl);
			Order order=new Order();
			order.setId(getOrderID());
			order.setDate(getDate());
			order.setGoodsName(getGoodsName());
			order.setNumber(getNumber());
			order.setPrice(getPrice());
			order.setSupply(getSupply());
			order.setState(getState());
			order.setActor(getActor());			
			purchaseservice.BuildOrder(order);
		}
		catch (Exception e) {
			 e.printStackTrace();
	    }
		return SUCCESS;
	}
	public String DelOrder() throws Exception{
		try{
			PurchaseImpl purchaseImpl=new PurchaseImpl();
			Purchaseservice purchaseservice=new Purchaseservice();
			purchaseservice.setPurchasedao(purchaseImpl);
			Order order=new Order();
			order.setId(getOrderID());
			purchaseservice.DelOrder(order);
		}
		catch (Exception e) {
			 e.printStackTrace();
	    }
		return SUCCESS;
	}
	public String NewSupply() throws Exception{
		try{
			PurchaseImpl purchaseImpl=new PurchaseImpl();
			Purchaseservice purchaseservice=new Purchaseservice();
			purchaseservice.setPurchasedao(purchaseImpl);
			Supply supply=new Supply();
			supply.setSupplyID(getSupplyID());
			supply.setSupplyname(getSupplyname());
			supply.setTel(getTel());
			supply.setAddress(getAddress());
			purchaseservice.NewSupply(supply);
		}
		catch (Exception e) {
			 e.printStackTrace();
	    }
		return SUCCESS;
	}
	public String DelSupply() throws Exception{
		try{
			PurchaseImpl purchaseImpl=new PurchaseImpl();
			Purchaseservice purchaseservice=new Purchaseservice();
			purchaseservice.setPurchasedao(purchaseImpl);
			Supply supply=new Supply();
			supply.setSupplyID(getSupplyID());			
			purchaseservice.DelSupply(supply);
		}
		catch (Exception e) {
			 e.printStackTrace();
	    }
		return SUCCESS;
	}

	
	

}

