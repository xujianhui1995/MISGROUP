package Action;

import java.sql.*;
import  java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

import Dao.LogindaoImpl;
import Dbutil.DbUtil;
import Entity.User;
import Service.Loginservice;

import org.apache.struts2.ServletActionContext;



public class LoginAction implements Action {
	private String userID;
	private String password;
	private String role;
	String SALE="sale";
	String PURCHASE="purchase";
	String STOCK="stock";
	String SUPER="super";
	
/****************************/	
	public String getUserID() {
		return userID;
	}


	public void setUserID(String userID) {
		this.userID = userID;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getRole() {
		return role;
	}


	public void setRole(String role) {
		this.role = role;
	}
/******************************/

	public String execute() throws Exception{
		LogindaoImpl logindaoImpl=new LogindaoImpl();
    	Loginservice loginservice=new Loginservice();
    	loginservice.setLogindao(logindaoImpl);
    	User u=loginservice.Login(getUserID());
		ActionContext ctx=ActionContext.getContext();		
		if(getPassword().equals(u.getPassword())  &&  u.getRoleID().equals("01"))
			{
			ctx.getSession().put("userName",u.getName());
			ctx.getSession().put("role",u.getRole());
			return SALE;
			}
		if(getPassword().equals(u.getPassword())  &&  u.getRoleID().equals("02"))
		{
		ctx.getSession().put("userName",u.getName());
		ctx.getSession().put("role",u.getRole());
		return PURCHASE;
		}
		if(getPassword().equals(u.getPassword())  &&  u.getRoleID().equals("03"))
		{
		ctx.getSession().put("userName",u.getName());
		ctx.getSession().put("role",u.getRole());
		return STOCK;
		}
		if(getPassword().equals(u.getPassword())  &&  u.getRoleID().equals("04"))
		{
		ctx.getSession().put("userName",u.getName());
		ctx.getSession().put("role",u.getRole());
		return SUPER;
		}
		else{
			return ERROR;
		}		
		
	}

}
