package Action;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionSupport;

import Dao.SaledaoImpl;
import Service.Saleservice;
import Entity.Store;
import Entity.Sale;
import Dbutil.DbUtil;

public class SaleAction extends ActionSupport {
	//��װ����
	private String oldstoreID;
	private String oldgoodsID;
	private String storeID;
	private String goodsName;
	private String goodsID;
	private String rest;
	private String[] goodsname;
	private String[] number;
	private String[] price;
	private String[] total;
	private String saleID;
	private String date;
	private String actor;


	
	public String getSaleID() {
		return saleID;
	}


	public void setSaleID(String saleID) {
		this.saleID = saleID;
	}


	public String getDate() {
		return date;
	}


	public void setDate(String date) {
		this.date = date;
	}


	public String getActor() {
		return actor;
	}


	public void setActor(String actor) {
		this.actor = actor;
	}


public String[] getGoodsname() {
		return goodsname;
	}


	public void setGoodsname(String[] goodsname) {
		this.goodsname = goodsname;
	}


	public String[] getNumber() {
		return number;
	}


	public void setNumber(String[] number) {
		this.number = number;
	}


	public String[] getPrice() {
		return price;
	}


	public void setPrice(String[] price) {
		this.price = price;
	}


	public String[] getTotal() {
		return total;
	}


	public void setTotal(String[] total) {
		this.total = total;
	}


/*************************************************/	
	
	public String getOldstoreID() {
		return oldstoreID;
	}


	public void setOldstoreID(String oldstoreID) {
		this.oldstoreID = oldstoreID;
	}


	public String getOldgoodsID() {
		return oldgoodsID;
	}


	public void setOldgoodsID(String oldgoodsID) {
		this.oldgoodsID = oldgoodsID;
	}


	public String getStoreID() {
		return storeID;
	}


	public void setStoreID(String storeID) {
		this.storeID = storeID;
	}


	public String getGoodsName() {
		return goodsName;
	}


	public void setGoodsName(String goodsName) {
		this.goodsName = goodsName;
	}


	public String getGoodsID() {
		return goodsID;
	}


	public void setGoodsID(String goodsID) {
		this.goodsID = goodsID;
	}


	public String getRest() {
		return rest;
	}


	public void setRest(String rest) {
		this.rest = rest;
	}
/***************************************************/
	public String AddStore() throws Exception{
		try{
			SaledaoImpl saledaoImpl=new SaledaoImpl();
	    	Saleservice saleservice=new Saleservice();
	    	saleservice.setSaledao(saledaoImpl);
			Store s=new Store();
			s.setStoreID(getStoreID());
			s.setGoodsID(getGoodsID());
			s.setGoodsName(getGoodsName());
			s.setRest(getRest());
			saleservice.addStore(s);
		}
		catch (Exception e) {
			 e.printStackTrace();
	    }
		return SUCCESS;
	}
	public String UpdateStore() throws Exception{
		try{
			SaledaoImpl saledaoImpl=new SaledaoImpl();
	    	Saleservice saleservice=new Saleservice();
	    	saleservice.setSaledao(saledaoImpl);
			Store s1=new Store();
			Store s2=new Store();
			s1.setStoreID(getOldstoreID());
			s1.setGoodsID(getOldgoodsID());
			s2.setStoreID(getStoreID());
			s2.setGoodsID(getGoodsID());
			s2.setGoodsName(getGoodsName());
			s2.setRest(getRest());
			saleservice.updateStore(s1, s2);
		}
		catch (Exception e) {
			 e.printStackTrace();
	    }
		return SUCCESS;
	}
	public String DelStore() throws Exception{
		try{
			SaledaoImpl saledaoImpl=new SaledaoImpl();
	    	Saleservice saleservice=new Saleservice();
	    	saleservice.setSaledao(saledaoImpl);
			Store store=new Store();
			store.setStoreID(getStoreID());
			store.setGoodsID(getGoodsID());			
			saleservice.delStore(store);
		}
		catch (Exception e) {
			 e.printStackTrace();
	    }
		return SUCCESS;
	}
	static List<Store> getStrore() throws Exception{		
			SaledaoImpl saledaoImpl=new SaledaoImpl();
	    	Saleservice saleservice=new Saleservice();
	    	saleservice.setSaledao(saledaoImpl);
	    	List<Store> storelist=saleservice.getStrore();		
		return storelist;
	}
	public String Account() throws Exception{
		try{
			SaledaoImpl saledaoImpl=new SaledaoImpl();
	    	Saleservice saleservice=new Saleservice();
	    	saleservice.setSaledao(saledaoImpl);
	    	List<Sale> list=new ArrayList<Sale>();
	    	for(int i = 0; i < goodsname.length; i++){
		    Sale sale=new Sale();
	    	sale.setGoodsName(goodsname[i]);
	    	sale.setNumber(number[i]);
	    	sale.setPrice(total[i]);
	    	sale.setSaleID(getSaleID());
	    	sale.setDate(getDate());
	    	sale.setActor(getActor());
	    	list.add(sale);	   	    	    		    	
	    	}
	    	saleservice.Account(list);
		}
		catch (Exception e) {
			 e.printStackTrace();
	    }
		return SUCCESS;
	}

}

