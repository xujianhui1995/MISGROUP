package Service;

import Dao.Logindao;
import Entity.User;
public class Loginservice {
	private Logindao logindao;
	public void setLogindao(Logindao logindao) {
		this.logindao = logindao;
	}	
	public User Login(String user) {
		return logindao.Login(user);
	}
	
		
}
