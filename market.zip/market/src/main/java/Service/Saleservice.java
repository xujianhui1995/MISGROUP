package Service;

import java.util.List;
import Dao.Saledao;
import Entity.Store;
import Entity.Sale;
public class Saleservice {
	private Saledao saledao;

	public void setSaledao(Saledao saledao) {
		this.saledao = saledao;
	}
	public List<Store> getStrore() {
		return saledao.getStrore();
	}
	public boolean addStore(Store s) {
		return saledao.AddStore(s);
	}
	public boolean updateStore(Store s1,Store s2) {
		return saledao.updateStore(s1, s2);
	}
	public boolean delStore(Store s) {
		return saledao.delStore(s);
	}
	public List<Store> Search(Store s) {
		return saledao.Search(s);
	}
	public List<Store> getLack() {
		return saledao.getLack();
	}
	public void Account(List<Sale> list) {
		saledao.Account(list);
	}	
}
