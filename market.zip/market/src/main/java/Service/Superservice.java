package Service;

import java.util.List;
import Dao.Saledao;
import Dao.Superdao;
import Entity.Store;
import Entity.User;
import Entity.Sale;
import Entity.Stock;
public class Superservice {
	private Superdao superdao;

	public void setSuperdao(Superdao superdao) {
		this.superdao = superdao;
	}
	public List<Stock> getStock() {
		return superdao.getStock();
	}
	public List<User> getUser() {
		return superdao.getUser();
	}
	public List<Sale> getSale() {
		return superdao.getSale();
	}
	public boolean UpdateUser(User user) {
		return superdao.UpdateUser(user);
	}
	public boolean DelUser(User user) {
		return superdao.DelUser(user);
	}	
}
