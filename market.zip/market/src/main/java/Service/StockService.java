package Service;

import java.util.List;

import Dao.StockDaoJDBCImpl;
import Entity.Goods;
import Entity.Stock;

public class StockService {
	private StockDaoJDBCImpl stockDao = new StockDaoJDBCImpl();

	public StockDaoJDBCImpl getStockDao() {
		return stockDao;
	}

	public void setStockDao(StockDaoJDBCImpl stockDao) {
		this.stockDao = stockDao;
	}

	public boolean addGood(Goods good) {
		return stockDao.addGood(good);
	}

	public List<Stock> getAll() {
		return stockDao.getAll();
	}
	public List<Stock> getAlarmStock(){
		return stockDao.getAlarmGood();
	}
	public Stock getBygoodsID(String goodsID){
		return stockDao.getBygoodsID(goodsID);
	}
	public boolean addNumber(Stock s,int addNumber){
		return stockDao.addNumber(s, addNumber);
	}
}
