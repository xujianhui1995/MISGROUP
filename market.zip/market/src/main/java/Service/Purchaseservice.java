package Service;

import java.util.List;

import Dao.Purchasedao;
import Entity.Order;
import Entity.Stock;
import Entity.Store;
import Entity.Supply;
public class Purchaseservice {
	private Purchasedao purchasedao;

	public void setPurchasedao(Purchasedao purchasedao) {
		this.purchasedao = purchasedao;
	}
	public List<Stock> getStock() {
		return purchasedao.getStock();
	}
	public List<Order> getOrder() {
		return purchasedao.getOrder();
		
	}
	public boolean BuildOrder(Order order) {
		return purchasedao.BuildOrder(order);
	}
	public boolean DelOrder(Order order) {
		return purchasedao.DelOrder(order);
	}
	public List<Order> Search(Order order) {
		return purchasedao.Search(order);
	}	
	public List<Supply> getSupply() {
		return purchasedao.getSupply();
	}
	public boolean NewSupply(Supply supply) {
		return purchasedao.NewSupply(supply);
	}
	public boolean DelSupply(Supply supply) {
		return purchasedao.DelSupply(supply);
	}
	public List<Supply> Search(Supply supply) {
		return purchasedao.Search(supply);
	}

		
}
