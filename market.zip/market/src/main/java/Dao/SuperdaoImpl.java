package Dao;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Entity.Sale;
import Entity.Stock;
import Entity.Store;
import Entity.User;
import Dbutil.DbUtil;

public class SuperdaoImpl implements Superdao {

	@Override
	public List<Stock> getStock() {
		// TODO Auto-generated method stub
		List<Stock> stockList=new ArrayList<Stock>();
		try{
			ResultSet rs= DbUtil.executeQuery("select * from stock", new Object[]{});
			while(rs.next()){
				Stock stock=new Stock();
				stock.setStockID(rs.getInt(1));
				stock.setGoodsID(rs.getString(2));
				stock.setGoodsName(rs.getString(3));
				stock.setRest(rs.getInt(4));
				stockList.add(stock);
			}					
		}catch(SQLException e){
			e.printStackTrace();
		}
		return stockList;
	}

	@Override
	public List<User> getUser() {
		// TODO Auto-generated method stub
		List<User> userlist=new ArrayList<User>();
		try{
			ResultSet rs= DbUtil.executeQuery("SELECT user.userID,user.name,user.password,user.tel,user.address,roles.roleName FROM user,roles where user.roleID=roles.roleID;", new Object[]{});
			while(rs.next()){
				User user=new User();
				user.setAddress(rs.getString(5));
				user.setName(rs.getString(2));
				user.setPassword(rs.getString(3));
				user.setRole(rs.getString(6));
				user.setTel(rs.getString(4));
				user.setUserID(rs.getString(1));
				userlist.add(user);
			}					
		}catch(SQLException e){
			e.printStackTrace();
		}
		return userlist;
	}

	@Override
	public List<Sale> getSale() {
		// TODO Auto-generated method stub
		List<Sale> saleList=new ArrayList<Sale>();
		try{
			ResultSet rs= DbUtil.executeQuery("select * from sale", new Object[]{});
			while(rs.next()){
				Sale sale=new Sale();
				sale.setActor(rs.getString(6));
				sale.setDate(rs.getString(2));
				sale.setNumber(rs.getString(4));
				sale.setGoodsName(rs.getString(3));
				sale.setPrice(rs.getString(5));
				sale.setSaleID(rs.getString(1));
				saleList.add(sale);
			}					
		}catch(SQLException e){
			e.printStackTrace();
		}
		return saleList;
	}

	@Override
	public boolean UpdateUser(User user) {
		// TODO Auto-generated method stub
		ResultSet rs= DbUtil.executeQuery("select * from user where userID=?", new Object[]{user.getUserID()});
		int count = 0;
	   	try {
	   			while(rs.next()){
	        	count = count + 1;
	            }
	        } catch (SQLException e1) {
	            // TODO Auto-generated catch block
	            e1.printStackTrace();
	        }
		if(count==0){
		return DbUtil.executeUpdate("insert into user values(?,?,?,?,?,?)", new Object[]{user.getUserID(),user.getRoleID(),user.getPassword(),user.getName(),user.getTel(),user.getAddress()});
		}
		else{
		return DbUtil.executeUpdate("update user set roleID=?,password=?,name=?,tel=?,address=? where userID=?;", new Object[]{user.getRoleID(),user.getPassword(),user.getName(),user.getTel(),user.getAddress(),user.getUserID()});
		}	
	}

	@Override
	public boolean DelUser(User user) {
		// TODO Auto-generated method stub
		return DbUtil.executeUpdate("delete user where userID=?", new Object[]{user.getUserID()});
	}
			
}
