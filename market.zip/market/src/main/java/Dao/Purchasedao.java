package Dao;

import java.util.List;
import Entity.Stock;
import Entity.Order;
import Entity.Supply;

public interface Purchasedao {
	public List<Stock> getStock();
	
	public List<Order> getOrder();
	public boolean BuildOrder(Order order);
	public boolean DelOrder(Order order);
	public List<Order> Search(Order order);
	
	public List<Supply> getSupply();
	public boolean NewSupply(Supply supply);
	public boolean DelSupply(Supply supply);
	public List<Supply> Search(Supply supply);

	
	
	
	
	
}
