package Dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.opensymphony.xwork2.ActionContext;

import Entity.Stock;
import Entity.Order;
import Entity.Supply;
import Dbutil.DbUtil;

public class PurchaseImpl implements Purchasedao {

	@Override
	public List<Stock> getStock() {
		// TODO Auto-generated method stub
		List<Stock> stockList=new ArrayList<Stock>();
		try{
			ResultSet rs= DbUtil.executeQuery("select * from stock where rest<10", new Object[]{});
			while(rs.next()){
				Stock stock=new Stock();
				stock.setStockID(rs.getInt(1));
				stock.setGoodsID(rs.getString(2));
				stock.setGoodsName(rs.getString(3));
				stock.setRest(rs.getInt(4));
				stockList.add(stock);
			}					
		}catch(SQLException e){
			e.printStackTrace();
		}
		return stockList;
	}

	@Override
	public List<Order> getOrder() {
		// TODO Auto-generated method stub
		List<Order> orderlist=new ArrayList<Order>();
		try{
			ResultSet rs= DbUtil.executeQuery("select * from orders", new Object[]{});
			while(rs.next()){
				Order order=new Order();
				order.setId(rs.getString(1));
				order.setDate(rs.getString(2));
				order.setGoodsName(rs.getString(3));
				order.setNumber(rs.getString(4));
				order.setState(rs.getString(7));
				order.setSupply(rs.getString(6));
				order.setActor(rs.getString(8));
				order.setPrice(rs.getString(5));
				orderlist.add(order);

			}					
		}catch(SQLException e){
			e.printStackTrace();
		}
		return orderlist;
	}

	@Override
	public boolean BuildOrder(Order order) {
		// TODO Auto-generated method stub
	return DbUtil.executeUpdate("INSERT INTO orders VALUES (?,?,?,?,?,?,?,?);", new Object[]{order.getId(),order.getDate(),order.getGoodsName(),order.getNumber(),order.getPrice(),order.getSupply(),order.getState(),order.getActor()});
	}

	@Override
	public boolean DelOrder(Order order) {
		// TODO Auto-generated method stub
		return DbUtil.executeUpdate("delete from orders where orderID=?", new Object[]{order.getId()});
	}

	@Override
	public List<Order> Search(Order order) {
		List<Order> orderlist=new ArrayList<Order>();
		try{
			ResultSet rs= DbUtil.executeQuery("select * from orders where orderID=?", new Object[]{order.getId()});
			while(rs.next()){
				Order o=new Order();
				o.setId(rs.getString(1));
				o.setDate(rs.getString(2));
				o.setGoodsName(rs.getString(3));
				o.setNumber(rs.getString(4));
				o.setState(rs.getString(7));
				o.setPrice(rs.getString(5));
				o.setSupply(rs.getString(6));
				o.setActor(rs.getString(8));
				orderlist.add(o);
			}					
		}catch(SQLException e){
			e.printStackTrace();
		}
		return orderlist;
	}

	@Override
	public List<Supply> getSupply() {
		// TODO Auto-generated method stub
		List<Supply> supplylist=new ArrayList<Supply>();
		ActionContext ctx=ActionContext.getContext();
		try{
			ResultSet rs= DbUtil.executeQuery("select * from supply", new Object[]{});
			while(rs.next()){
				Supply s=new Supply();
				s.setSupplyID(rs.getString(1));
				s.setSupplyname(rs.getString(2));
				s.setTel(rs.getString(3));
				s.setAddress(rs.getString(4));
				supplylist.add(s);
			}
			ctx.getSession().put("supplylist",supplylist);
		}catch(SQLException e){
			e.printStackTrace();
		}
		return supplylist;
	}

	@Override
	public boolean NewSupply(Supply supply) {
		// TODO Auto-generated method stub
		ResultSet rs= DbUtil.executeQuery("select * from supply where supplyID=?", new Object[]{supply.getSupplyID()});
		int count = 0;
	   	try {
	   			while(rs.next()){
	        	count = count + 1;
	            }
	        } catch (SQLException e1) {
	            // TODO Auto-generated catch block
	            e1.printStackTrace();
	        }
		if(count==0){
		return DbUtil.executeUpdate("insert into supply values(?,?,?,?);", new Object[]{supply.getSupplyID(),supply.getSupplyname(),supply.getTel(),supply.getAddress()});
		}
		else{
		return DbUtil.executeUpdate("update supply set supplyname=?,tel=?,address=? where supplyID=?", new Object[]{supply.getSupplyname(),supply.getTel(),supply.getAddress(),supply.getSupplyID()});	
		}
	}

	@Override
	public boolean DelSupply(Supply supply) {
		// TODO Auto-generated method stub
		return DbUtil.executeUpdate("delete from supply where supplyID=?", new Object[]{supply.getSupplyID()});
	}

	@Override
	public List<Supply> Search(Supply supply) {
		// TODO Auto-generated method stub
		List<Supply> supplylist=new ArrayList<Supply>();
		try{
			ResultSet rs= DbUtil.executeQuery("select * from supply where supplyID=?", new Object[]{supply.getSupplyID()});
			while(rs.next()){
				Supply supply1=new Supply();
				supply1.setSupplyID(rs.getString(1));
				supply1.setSupplyname(rs.getString(2));
				supply1.setTel(rs.getString(3));
				supply1.setAddress(rs.getString(4));
				supplylist.add(supply1);				
			}					
		}catch(SQLException e){
			e.printStackTrace();
		}
		return supplylist;
	}

	
	
	
}
