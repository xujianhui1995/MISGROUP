package Dao;

import java.util.List;
import Entity.Store;
import Entity.User;
import Entity.Order;
import Entity.Sale;
import Entity.Stock;
public interface Superdao {
	public List<Stock> getStock();
	public List<User> getUser();
	public List<Sale> getSale();
	public boolean UpdateUser(User user);
	public boolean DelUser(User user);	
}
