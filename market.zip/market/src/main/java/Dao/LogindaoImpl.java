package Dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import Dbutil.DbUtil;
import Entity.User;

public class LogindaoImpl implements Logindao {

	@Override
	public User Login(String user) {
		// TODO Auto-generated method stub
		User u=new User();
		try{
		ResultSet rs= DbUtil.executeQuery("select * from user left join roles on user.roleID=roles.roleID where user.userID=?", new Object[]{user});
		while(rs.next()){			
			u.setRoleID(rs.getString(2));
			u.setPassword(rs.getString(3));	
			u.setRole(rs.getString(8));
			u.setName(rs.getString(4));
		}					
	}catch(SQLException e){
		e.printStackTrace();
	}
	return u;
}
		
	

}
