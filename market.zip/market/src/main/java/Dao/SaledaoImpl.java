package Dao;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Entity.Sale;
import Entity.Store;
import Dbutil.DbUtil;

public class SaledaoImpl implements Saledao {
	/*************/
	@Override
	public List<Store> getStrore() {
		// TODO Auto-generated method stub
		List<Store> storeList=new ArrayList<Store>();
		try{
			ResultSet rs= DbUtil.executeQuery("select * from store", new Object[]{});
			while(rs.next()){
				Store store=new Store();
				store.setStoreID(rs.getString(1));
				store.setGoodsID(rs.getString(2));
				store.setGoodsName(rs.getString(3));
				store.setRest(rs.getString(4));
				storeList.add(store);
			}					
		}catch(SQLException e){
			e.printStackTrace();
		}
		return storeList;
	}

	@Override
	public boolean updateStore(Store s1, Store s2) {
		// TODO Auto-generated method stub
		return DbUtil.executeUpdate("update store set storeID=?,goodsID=?,goodsName=?,rest=? where storeID=? and goodsID=?", new Object[]{s2.getStoreID(),s2.getGoodsID(),s2.getGoodsName(),s2.getRest(),s1.getStoreID(),s1.getGoodsID()});
	}
	@Override
	public boolean AddStore(Store s) {
		// TODO Auto-generated method stub
		return DbUtil.executeUpdate("insert into store value(?,?,?,?)", new Object[]{s.getStoreID(),s.getGoodsID(),s.getGoodsName(),s.getRest()});
	}
	@Override
	public boolean delStore(Store store) {
		// TODO Auto-generated method stub
		return DbUtil.executeUpdate("delete from store where storeID=? and goodsID=?", new Object[]{store.getStoreID(),store.getGoodsID()});
	}
	@Override
	public List<Store> Search(Store store) {
		// TODO Auto-generated method stub
		List<Store> SearchList=new ArrayList<Store>();
		try{
			ResultSet rs= DbUtil.executeQuery("select * from store where goodsID=?", new Object[]{store.getGoodsID()});
			while(rs.next()){
				Store search=new Store();
				search.setStoreID(rs.getString(1));
				search.setGoodsID(rs.getString(2));
				search.setGoodsName(rs.getString(3));
				search.setRest(rs.getString(4));
				SearchList.add(search);
			}					
		}catch(SQLException e){
			e.printStackTrace();
		}
		return SearchList;
	}

	@Override
	public List<Store> getLack() {
		// TODO Auto-generated method stub
		List<Store> LackList=new ArrayList<Store>();
		try{
			ResultSet rs= DbUtil.executeQuery("select * from store where rest<10", new Object[]{});
			while(rs.next()){
				Store lack=new Store();
				lack.setStoreID(rs.getString(1));
				lack.setGoodsID(rs.getString(2));
				lack.setGoodsName(rs.getString(3));
				lack.setRest(rs.getString(4));
				LackList.add(lack);
			}					
		}catch(SQLException e){
			e.printStackTrace();
		}
		return LackList;
	}

	@Override
	public void Account(List<Sale> list) {
		// TODO Auto-generated method stub
		String rest=null;
		for(int i = 0; i < list.size(); i++){ 
			DbUtil.executeUpdate("insert into sale value(?,?,?,?,?,?)", new Object[]{list.get(i).getSaleID(),list.get(i).getDate(),list.get(i).getGoodsName(),list.get(i).getNumber(),list.get(i).getPrice(),list.get(i).getActor()});
			ResultSet rs=DbUtil.executeQuery("select * from store where goodsName=?",new Object[]{list.get(i).getGoodsName()});	
		try{
			while(rs.next()){			
			rest=rs.getString(4);
			} 
			BigDecimal num1 = new BigDecimal(rest);
			BigDecimal num2 = new BigDecimal(list.get(i).getNumber()); 
			BigDecimal result = num1.subtract(num2);
			DbUtil.executeUpdate("update store set rest=? where goodsName=?", new Object[]{result.toString(),list.get(i).getGoodsName()});
		}catch(SQLException e){
			e.printStackTrace();
		}
		}
	}		
}
