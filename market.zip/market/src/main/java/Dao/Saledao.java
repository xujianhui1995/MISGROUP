package Dao;

import java.util.List;
import Entity.Store;
import Entity.Sale;
public interface Saledao {
	public List<Store> getStrore();
	public boolean AddStore(Store s);
	public boolean updateStore(Store s1,Store s2);
	public boolean delStore(Store s);
	public List<Store> Search(Store s);
	public List<Store> getLack();
	public void Account(List<Sale> list);
	
	
	
	
}
