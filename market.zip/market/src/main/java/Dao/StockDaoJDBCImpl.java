package Dao;

import java.sql.ResultSet;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Dbutil.DbUtil;
import Entity.Goods;
import Entity.Stock;

public class StockDaoJDBCImpl implements StockDao {

	@Override
	public boolean addGood(Goods good) {
		return DbUtil.executeUpdate(
				"insert into goods(goodsID,goodsName,sortID,unit,date,safety,price) values (?,?,?,?,?,?,?)",
				new Object[] { good.getGoodsID(), good.getGoodsName(), good.getSortID(), good.getUnit(),good.getDate(),good.getSafety(),good.getPrice() });
	}

	@Override
	public List<Stock> getAll() {
		ResultSet rs=DbUtil.executeQuery("select * from stock ", new Object[]{});
		List<Stock> list = new ArrayList<Stock>(); //
		try {
			while (rs.next()) {
				Stock s = new Stock();
				s.setGoodsID(rs.getString("goodsID"));
				s.setStockID(rs.getInt("stockID"));
				s.setGoodsName(rs.getString("goodsName"));
				s.setRest(rs.getInt("rest"));				
				list.add(s);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public List<Stock> getAlarmGood() {
		ResultSet rs=DbUtil.executeQuery("select * from stock where rest<10 ", new Object[]{});
		List<Stock> list = new ArrayList<Stock>(); //
		try {
			while (rs.next()) {
				Stock s = new Stock();
				s.setGoodsID(rs.getString("stockID"));
				s.setStockID(rs.getInt("goodsID"));
				s.setGoodsName(rs.getString("goodsName"));
				s.setRest(rs.getInt("rest"));				
				list.add(s);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public Stock getBygoodsID(String goodsID) {
		ResultSet rs = DbUtil.executeQuery("select * from stock where goodsID=?", new Object[] { goodsID });
		Stock s = null;
		try {
			while (rs.next()) {
				s = new Stock();
				s.setStockID(rs.getInt("stockID"));
				s.setGoodsName(rs.getString("goodsName"));
				s.setRest(rs.getInt("rest"));
			    
				return s;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return s;
	}

	@Override
	public boolean addNumber(Stock s, int addNumber) {
		return DbUtil.executeUpdate("update stock set rest=? where stockID=?",new Object[] { s.getRest()+addNumber,s.getStockID() });
	}

	
  
}
