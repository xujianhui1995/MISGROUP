package Dao;

import Entity.User;

public  interface Logindao {
	public User Login(String user);

}
